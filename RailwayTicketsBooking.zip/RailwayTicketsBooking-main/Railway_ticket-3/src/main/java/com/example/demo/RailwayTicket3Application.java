package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayTicket3Application {

	public static void main(String[] args) {
		SpringApplication.run(RailwayTicket3Application.class, args);
	}

}
